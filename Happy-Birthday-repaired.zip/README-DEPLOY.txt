Happy-Birthday — GitHub Pages repair

1. Upload the CONTENTS of this folder to the ROOT of your GitHub repository (not inside "with love").
2. Commit/push to the main branch.
3. Repository Settings > Pages:
   - Source: Deploy from a branch
   - Branch: main
   - Folder: /(root)
4. Wait for the Pages deployment in Actions to finish, then open:
   https://langitmeraki.github.io/Happy-Birthday/

Repair included:
- Added index.html at the repository root (GitHub Pages entry point).
- Kept the original with-love.html and its assets.
- Changed the published-media URLs to be relative to the project site path.
- Corrected the Open Graph logo path.

Important missing media:
The original HTML references 25 uploaded image files under /api/published-media/... but those image files are not present in the ZIP you supplied. The /api/published-media folder contains only an index.html. Those specific photos may therefore remain unavailable until you provide the original media files. Existing assets in /assets are preserved.
